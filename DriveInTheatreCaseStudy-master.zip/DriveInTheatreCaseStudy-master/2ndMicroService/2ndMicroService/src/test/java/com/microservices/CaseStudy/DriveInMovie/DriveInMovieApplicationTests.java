package com.microservices.CaseStudy.DriveInMovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriveInMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
