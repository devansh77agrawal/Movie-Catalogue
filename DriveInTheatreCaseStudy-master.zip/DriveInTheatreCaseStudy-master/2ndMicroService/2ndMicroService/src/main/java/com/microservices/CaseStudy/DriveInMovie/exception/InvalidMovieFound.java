package com.microservices.CaseStudy.DriveInMovie.exception;



public class InvalidMovieFound extends Exception {

	public InvalidMovieFound(String msg)
	{
		super(msg);
	}
}
