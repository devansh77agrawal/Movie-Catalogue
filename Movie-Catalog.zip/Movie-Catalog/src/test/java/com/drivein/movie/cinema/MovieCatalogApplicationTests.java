package com.drivein.movie.cinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
