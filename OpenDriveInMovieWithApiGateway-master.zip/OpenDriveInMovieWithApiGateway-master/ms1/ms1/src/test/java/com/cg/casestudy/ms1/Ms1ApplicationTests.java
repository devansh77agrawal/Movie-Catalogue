package com.cg.casestudy.ms1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ms1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
