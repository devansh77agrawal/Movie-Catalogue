package com.cg.casestudy.ms2.exception;

public class InvalidMovieFound extends Exception {

	public InvalidMovieFound(String msg)
	{
		super(msg);
	}
}