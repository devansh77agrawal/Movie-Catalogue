package com.cg.casestudy.ms2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ms2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
