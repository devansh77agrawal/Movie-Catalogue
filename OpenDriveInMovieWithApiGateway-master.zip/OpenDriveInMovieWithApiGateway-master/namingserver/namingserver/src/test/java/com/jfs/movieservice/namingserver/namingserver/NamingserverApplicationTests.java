package com.jfs.movieservice.namingserver.namingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
