package com.cg.jfs.casestudy.ms3;

public class InvalidSeatException extends Exception {
	
	public InvalidSeatException(String msg)
	{
		super(msg);
	}

}
